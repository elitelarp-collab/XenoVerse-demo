# XenoVerse

A futuristic dark-blue Minecraft client for **Minecraft 1.21.11** on **Fabric** (Java 21).

> **Status: Phase 1 of 4 (foundation).** This build loads in the game and sets up the config
> system, but it does not show any menus or modules yet. See the roadmap below.

## Roadmap

| Phase | Contents | Status |
|-------|----------|--------|
| 1 | Project + build files, config system (profiles, import/export), module framework (settings, keybinds, favourites, recents, search), theme + animation engine, logo and icons | **Done** |
| 2 | Redesigned main menu, searchable mod menu, HUD editor | Next |
| 3 | The 50 modules (10 categories x 5) with real functionality | Planned |
| 4 | Cosmetics (local vs server-authorised), Microsoft account manager (official login, no passwords stored) | Planned |

## Build the JAR from a phone (no PC needed): GitHub Actions

1. Create a free account at github.com and make a **new repository** (private is fine).
2. In the repository choose **Add file -> Upload files** and upload `XenoVerse-Phase1.zip`
   (leave it zipped). Commit.
3. Choose **Add file -> Create new file**. In the name box type exactly
   `.github/workflows/build.yml`, paste the workflow text (it is also inside this ZIP at that path),
   and commit.
4. Open the **Actions** tab, open the newest "Build XenoVerse" run, wait for the green tick
   (about 3-6 minutes), then download **XenoVerse-jar** from the "Artifacts" section.
5. Unzip the download to get `XenoVerse.jar`.
6. If the run is red, open the failed step, copy the red error text and send it to Claude.

## Build on a PC

Requires JDK 21 and Gradle 9.2+ (or run `gradle wrapper` once to create `./gradlew`).

    gradle build

The JAR is written to `build/libs/XenoVerse-0.1.0.jar` (ignore the `-sources` jar).

## Install

1. Install Minecraft 1.21.11 with **Fabric Loader 0.18.4 or newer**.
2. Put **Fabric API for 1.21.11** and `XenoVerse.jar` into the `mods` folder.
3. Start the game. The log shows `XenoVerse 0.1.0 for Minecraft 1.21.11 started`.

## Where settings are stored

`.minecraft/config/xenoverse/config.properties` (global settings) and
`.minecraft/config/xenoverse/profiles/<name>.properties` (per-profile module settings).
Profiles can be exported to a single line of text (`XV1:...`) and imported again.

## Versions used

Minecraft 1.21.11 | Fabric Loader 0.18.4 | Fabric API 0.141.1+1.21.11 | Fabric Loom 1.14.10 |
Yarn 1.21.11+build.4 | Gradle 9.2.1 | Java 21. These come from community projects targeting
1.21.11 and have not been checked against Fabric's own version page. If Gradle reports that a
version does not exist, change it in `gradle.properties`.

## Project layout

    src/main/java/dev/xenoverse/
      XenoVerseClient.java   Fabric entry point
      XenoVerse.java         service hub (settings, modules, config, theme)
      core/                  Module, ModuleManager, Category, setting types
      config/                ConfigManager, ClientSettings, file format
      ui/                    Theme (colours), anim/ (easing, animations)
      util/                  colour helpers, logging
    tools/generate_assets.py regenerates the logo and icons

## License

MIT
