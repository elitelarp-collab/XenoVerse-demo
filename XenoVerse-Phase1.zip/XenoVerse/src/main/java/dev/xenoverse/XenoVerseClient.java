package dev.xenoverse;

import dev.xenoverse.util.Log;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;

/** Fabric client entry point. Kept tiny: all logic lives in {@link XenoVerse}. */
public final class XenoVerseClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        try {
            FabricLoader loader = FabricLoader.getInstance();
            String version = loader.getModContainer(XenoVerse.ID)
                .map(container -> container.getMetadata().getVersion().getFriendlyString())
                .orElse("dev");
            XenoVerse.init(loader.getConfigDir().resolve(XenoVerse.ID), version);
        } catch (Throwable t) {
            // Never stop the game from starting because of this mod.
            Log.error("XenoVerse failed to start and has been disabled for this session", t);
            return;
        }
        ClientTickEvents.END_CLIENT_TICK.register(client -> XenoVerse.get().tick());
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> XenoVerse.get().shutdown());
    }
}
