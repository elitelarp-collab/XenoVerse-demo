package dev.xenoverse.ui;

import dev.xenoverse.util.ColorUtil;

/**
 * The XenoVerse colour system: dark navy surfaces with electric-blue accents.
 * Every colour is derived from a preset plus a single "blue intensity" slider (0..1),
 * so the whole interface re-colours consistently.
 */
public final class Theme {

    public enum Preset {
        ELECTRIC_BLUE("Electric Blue", 0.585f, 0.640f, 0.620f),
        DEEP_NAVY("Deep Navy", 0.620f, 0.580f, 0.640f),
        ICE("Ice", 0.545f, 0.600f, 0.600f),
        NEON_CYAN("Neon Cyan", 0.505f, 0.585f, 0.590f),
        MIDNIGHT_VIOLET("Midnight Violet", 0.735f, 0.600f, 0.700f);

        public final String label;
        final float accentHue;
        final float secondHue;
        final float backgroundHue;

        Preset(String label, float accentHue, float secondHue, float backgroundHue) {
            this.label = label;
            this.accentHue = accentHue;
            this.secondHue = secondHue;
            this.backgroundHue = backgroundHue;
        }
    }

    /** Labels in display order, for the theme selector setting. */
    public static String[] presetLabels() {
        Preset[] all = Preset.values();
        String[] labels = new String[all.length];
        for (int i = 0; i < all.length; i++) labels[i] = all[i].label;
        return labels;
    }

    public static Preset presetByLabel(String label) {
        for (Preset p : Preset.values()) {
            if (p.label.equalsIgnoreCase(label)) return p;
        }
        return Preset.ELECTRIC_BLUE;
    }

    // Fixed colours
    public static final int TEXT_PRIMARY = 0xFFE8EEFF;
    public static final int TEXT_SECONDARY = 0xFF8D9BC2;
    public static final int TEXT_DISABLED = 0xFF55618A;
    public static final int SUCCESS = 0xFF34D399;
    public static final int WARNING = 0xFFFBBF24;
    public static final int DANGER = 0xFFF87171;

    private Preset preset = Preset.ELECTRIC_BLUE;
    private float intensity = 0.8f;

    private int accent, accentAlt, accentSoft, accentGlow;
    private int backgroundDeep, background, panel, panelHover, panelActive, outline;

    public Theme() {
        rebuild();
    }

    public synchronized void set(Preset preset, double intensity) {
        this.preset = preset == null ? Preset.ELECTRIC_BLUE : preset;
        this.intensity = (float) ColorUtil.clamp01(intensity);
        rebuild();
    }

    private void rebuild() {
        float i = intensity;
        accent = ColorUtil.hsb(preset.accentHue, mix(0.45f, 0.95f, i), mix(0.78f, 1.00f, i));
        accentAlt = ColorUtil.hsb(preset.secondHue, mix(0.55f, 1.00f, i), mix(0.55f, 0.90f, i));
        accentSoft = ColorUtil.withAlpha(accent, 0x66);
        accentGlow = ColorUtil.withAlpha(accent, 0x2E);
        float h = preset.backgroundHue;
        backgroundDeep = ColorUtil.hsb(h, 0.88f, mix(0.06f, 0.09f, i));
        background = ColorUtil.hsb(h, 0.82f, mix(0.10f, 0.15f, i));
        panel = ColorUtil.hsb(h, 0.76f, mix(0.14f, 0.21f, i));
        panelHover = ColorUtil.hsb(h, 0.70f, mix(0.19f, 0.27f, i));
        panelActive = ColorUtil.hsb(h, 0.68f, mix(0.24f, 0.33f, i));
        outline = ColorUtil.lerp(panelHover, accent, 0.35);
    }

    private static float mix(float a, float b, float t) {
        return a + (b - a) * t;
    }

    /** Blend along the accent gradient, t = 0 (accent) .. 1 (alternate accent). */
    public int gradient(double t) {
        return ColorUtil.lerp(accent, accentAlt, t);
    }

    public Preset preset() { return preset; }
    public float intensity() { return intensity; }
    public int accent() { return accent; }
    public int accentAlt() { return accentAlt; }
    public int accentSoft() { return accentSoft; }
    public int accentGlow() { return accentGlow; }
    public int backgroundDeep() { return backgroundDeep; }
    public int background() { return background; }
    public int panel() { return panel; }
    public int panelHover() { return panelHover; }
    public int panelActive() { return panelActive; }
    public int outline() { return outline; }
}
