package dev.xenoverse.ui.anim;

/** Global animation switches, driven by the client settings. */
public final class Motion {
    private static volatile boolean enabled = true;
    private static volatile double speed = 1.0;

    private Motion() {}

    public static boolean isEnabled() { return enabled; }
    public static double speed() { return speed; }

    public static void configure(boolean enabled, double speed) {
        Motion.enabled = enabled;
        Motion.speed = Math.max(0.1, Math.min(4.0, speed));
    }
}
