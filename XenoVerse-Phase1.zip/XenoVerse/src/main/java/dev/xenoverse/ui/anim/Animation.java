package dev.xenoverse.ui.anim;

/**
 * A timed 0..1 transition that can run forwards or backwards, e.g. a hover highlight,
 * a toggle switch or a panel sliding in. Call {@link #update()} once per frame.
 * Respects the global {@link Motion} settings (disabled animations jump straight to the end).
 */
public final class Animation {
    private static final long MAX_FRAME_NANOS = 100_000_000L; // ignore hitches longer than 100 ms

    private final long durationMillis;
    private final Easing easing;
    private double progress;
    private boolean forward;
    private long lastNanos = System.nanoTime();

    public Animation(long durationMillis, Easing easing) {
        this(durationMillis, easing, false);
    }

    public Animation(long durationMillis, Easing easing, boolean startOn) {
        if (durationMillis <= 0) throw new IllegalArgumentException("duration must be > 0");
        this.durationMillis = durationMillis;
        this.easing = easing;
        this.forward = startOn;
        this.progress = startOn ? 1 : 0;
    }

    /** Sets the direction. With animations disabled this snaps instantly. */
    public void setTarget(boolean on) {
        forward = on;
        if (!Motion.isEnabled()) {
            progress = on ? 1 : 0;
        }
    }

    public boolean getTarget() { return forward; }

    public void snap(boolean on) {
        forward = on;
        progress = on ? 1 : 0;
    }

    /** Advances using wall-clock time. Returns the eased value (0..1). */
    public double update() {
        long now = System.nanoTime();
        long delta = Math.min(now - lastNanos, MAX_FRAME_NANOS);
        lastNanos = now;
        return advance(delta / 1_000_000.0);
    }

    /** Advances by an explicit number of milliseconds (used for deterministic tests). */
    public double advance(double millis) {
        if (!Motion.isEnabled()) {
            progress = forward ? 1 : 0;
        } else {
            double step = millis * Motion.speed() / durationMillis;
            progress = forward ? Math.min(1, progress + step) : Math.max(0, progress - step);
        }
        return value();
    }

    public double value() { return easing.apply(progress); }
    public double rawProgress() { return progress; }
    public boolean isFinished() { return forward ? progress >= 1 : progress <= 0; }
}
