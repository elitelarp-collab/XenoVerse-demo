package dev.xenoverse.ui.anim;

/** Easing curves. Every curve maps 0 -> 0 and 1 -> 1. */
public enum Easing {
    LINEAR {
        @Override public double apply(double t) { return t; }
    },
    EASE_OUT_CUBIC {
        @Override public double apply(double t) { double u = 1 - t; return 1 - u * u * u; }
    },
    EASE_IN_OUT_CUBIC {
        @Override public double apply(double t) {
            return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
        }
    },
    EASE_OUT_EXPO {
        @Override public double apply(double t) { return t >= 1 ? 1 : 1 - Math.pow(2, -10 * t); }
    },
    EASE_OUT_BACK {
        @Override public double apply(double t) {
            double c1 = 1.70158, c3 = c1 + 1;
            double u = t - 1;
            return 1 + c3 * u * u * u + c1 * u * u;
        }
    },
    EASE_IN_OUT_SINE {
        @Override public double apply(double t) { return -(Math.cos(Math.PI * t) - 1) / 2; }
    };

    public abstract double apply(double t);

    /** Clamps the input to 0..1 before applying the curve. */
    public double applyClamped(double t) {
        return apply(t < 0 ? 0 : Math.min(t, 1));
    }
}
