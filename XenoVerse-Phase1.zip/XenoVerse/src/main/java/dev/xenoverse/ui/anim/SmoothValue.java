package dev.xenoverse.ui.anim;

/**
 * A number that glides towards a target (frame-rate independent exponential smoothing).
 * Good for scrolling, sliders, dragging and counters.
 */
public final class SmoothValue {
    private double current;
    private double target;
    private final double rate; // higher = snappier (about 8..20 feels good)
    private long lastNanos = System.nanoTime();

    public SmoothValue(double initial, double rate) {
        this.current = initial;
        this.target = initial;
        this.rate = Math.max(0.1, rate);
    }

    public void setTarget(double target) { this.target = target; }
    public double getTarget() { return target; }
    public double get() { return current; }

    public void snap(double value) { current = value; target = value; }

    public double update() {
        long now = System.nanoTime();
        double seconds = Math.min((now - lastNanos) / 1_000_000_000.0, 0.1);
        lastNanos = now;
        return advance(seconds);
    }

    public double advance(double seconds) {
        if (!Motion.isEnabled()) {
            current = target;
            return current;
        }
        double k = 1.0 - Math.exp(-rate * Motion.speed() * seconds);
        current += (target - current) * k;
        if (Math.abs(target - current) < 1e-4) current = target;
        return current;
    }

    public boolean isSettled() { return current == target; }
}
