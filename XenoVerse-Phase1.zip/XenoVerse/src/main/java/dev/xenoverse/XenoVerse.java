package dev.xenoverse;

import dev.xenoverse.config.ClientSettings;
import dev.xenoverse.config.ConfigManager;
import dev.xenoverse.core.ModuleManager;
import dev.xenoverse.ui.Theme;
import dev.xenoverse.ui.anim.Motion;
import dev.xenoverse.util.Log;

import java.nio.file.Path;

/** Central access point for the client's services. Created once by {@link XenoVerseClient}. */
public final class XenoVerse {
    public static final String NAME = "XenoVerse";
    public static final String ID = "xenoverse";
    public static final String MINECRAFT_VERSION = "1.21.11";

    private static final int AUTOSAVE_TICKS = 200; // every 10 seconds, only when something changed
    private static XenoVerse instance;

    private final String version;
    private final ClientSettings settings = new ClientSettings();
    private final ModuleManager modules = new ModuleManager();
    private final Theme theme = new Theme();
    private final ConfigManager config;
    private int ticks;

    private XenoVerse(Path configDir, String version) {
        this.version = version;
        this.config = new ConfigManager(configDir, settings, modules);
    }

    /** Creates the client. Safe to call more than once (later calls are ignored). */
    public static synchronized void init(Path configDir, String version) {
        if (instance != null) return;
        XenoVerse client = new XenoVerse(configDir, version);
        client.start();
        instance = client;
    }

    public static XenoVerse get() {
        if (instance == null) throw new IllegalStateException("XenoVerse is not initialised yet");
        return instance;
    }

    public static boolean isReady() { return instance != null; }

    private void start() {
        // Built-in modules are registered here (one class per category, added in later phases).
        BuiltinModules.registerAll(modules);

        modules.setDirtyCallback(config::markDirty);
        for (var setting : settings.getSettings()) setting.addListener(v -> {
            config.markDirty();
            applyAppearance();
        });
        config.load();
        applyAppearance();
        Log.info(NAME + " " + version + " for Minecraft " + MINECRAFT_VERSION
            + " started with " + modules.all().size() + " modules.");
    }

    /** Pushes the theme and animation settings into the UI systems. */
    private void applyAppearance() {
        theme.set(Theme.presetByLabel(settings.theme.get()), settings.blueIntensity.asDouble() / 100.0);
        Motion.configure(settings.animations.isOn(), settings.animationSpeed.asDouble());
    }

    /** Called once per client tick. Never throws. */
    public void tick() {
        try {
            modules.tick();
            if (++ticks >= AUTOSAVE_TICKS) {
                ticks = 0;
                config.saveIfDirty();
            }
        } catch (RuntimeException e) {
            Log.error("Unexpected error during tick", e);
        }
    }

    public void shutdown() {
        config.save();
    }

    public String version() { return version; }
    public ClientSettings settings() { return settings; }
    public ModuleManager modules() { return modules; }
    public ConfigManager config() { return config; }
    public Theme theme() { return theme; }
}
