package dev.xenoverse.config;

import dev.xenoverse.core.setting.BooleanSetting;
import dev.xenoverse.core.setting.KeybindSetting;
import dev.xenoverse.core.setting.ModeSetting;
import dev.xenoverse.core.setting.NumberSetting;
import dev.xenoverse.core.setting.Setting;
import dev.xenoverse.core.setting.SettingsHolder;
import dev.xenoverse.ui.Theme;

import java.util.Map;

/** Global (not per-profile) client settings shown on the Settings screen. */
public final class ClientSettings extends SettingsHolder {
    public final NumberSetting guiScale = add(new NumberSetting(
        "gui_scale", "GUI scale", "Size of the XenoVerse interface", 1.0, 0.5, 2.0, 0.05));
    public final ModeSetting theme = add(new ModeSetting(
        "theme", "Theme", "Colour preset for the whole interface", "Electric Blue", Theme.presetLabels()));
    public final NumberSetting blueIntensity = add(new NumberSetting(
        "blue_intensity", "Blue intensity", "How vivid the accent colours are", 80, 0, 100, 1));
    public final BooleanSetting animations = add(new BooleanSetting(
        "animations", "Animations", "Smooth transitions in menus", true));
    public final NumberSetting animationSpeed = add(new NumberSetting(
        "animation_speed", "Animation speed", "1.0 is normal; higher is faster", 1.0, 0.25, 2.0, 0.05));
    public final BooleanSetting animatedBackground = add(new BooleanSetting(
        "animated_background", "Animated background", "Moving background on the main menu", true));
    public final BooleanSetting sounds = add(new BooleanSetting(
        "ui_sounds", "Interface sounds", "Click and toggle sounds in XenoVerse menus", true));
    public final NumberSetting soundVolume = add(new NumberSetting(
        "sound_volume", "Interface volume", "Volume of XenoVerse interface sounds", 60, 0, 100, 5));
    public final KeybindSetting menuKey = add(new KeybindSetting(
        "menu_key", "Mod menu key", "Opens the XenoVerse mod menu", 344)); // Right Shift
    public final KeybindSetting hudEditorKey = add(new KeybindSetting(
        "hud_editor_key", "HUD editor key", "Opens the HUD editor", KeybindSetting.NONE));

    public ClientSettings() {
        animationSpeed.visibleWhen(animations::isOn);
        soundVolume.visibleWhen(sounds::isOn);
    }

    public void writeTo(Map<String, String> out) {
        for (Setting<?> s : getSettings()) out.put("client." + s.key(), s.serialize());
    }

    public void readFrom(Map<String, String> in) {
        for (Setting<?> s : getSettings()) {
            String v = in.get("client." + s.key());
            if (v != null) s.deserialize(v);
        }
    }
}
