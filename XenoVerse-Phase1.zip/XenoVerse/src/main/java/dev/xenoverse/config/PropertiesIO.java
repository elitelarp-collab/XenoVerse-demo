package dev.xenoverse.config;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

/** Minimal, dependency-free "key=value" file format (UTF-8, '#' comments, \n escapes). */
final class PropertiesIO {
    static final long MAX_BYTES = 1_048_576; // refuse to read files larger than 1 MB

    private PropertiesIO() {}

    static Map<String, String> parse(String text) {
        Map<String, String> map = new LinkedHashMap<>();
        for (String raw : text.split("\n", -1)) {
            String line = raw.endsWith("\r") ? raw.substring(0, raw.length() - 1) : raw;
            if (line.isEmpty() || line.startsWith("#")) continue;
            int eq = line.indexOf('=');
            if (eq <= 0) continue;
            map.put(line.substring(0, eq).trim(), unescape(line.substring(eq + 1)));
        }
        return map;
    }

    static String write(Map<String, String> map, String header) {
        StringBuilder sb = new StringBuilder();
        if (header != null) sb.append("# ").append(header).append('\n');
        for (Map.Entry<String, String> e : new TreeMap<>(map).entrySet()) {
            sb.append(e.getKey()).append('=').append(escape(e.getValue())).append('\n');
        }
        return sb.toString();
    }

    static Map<String, String> read(Path file) throws IOException {
        if (Files.size(file) > MAX_BYTES) throw new IOException("File too large: " + file);
        return parse(Files.readString(file, StandardCharsets.UTF_8));
    }

    /** Writes to a temp file first so a crash can never leave a half-written config behind. */
    static void writeAtomic(Path file, String content) throws IOException {
        Files.createDirectories(file.getParent());
        Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
        Files.writeString(tmp, content, StandardCharsets.UTF_8);
        try {
            Files.move(tmp, file, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } catch (AtomicMoveNotSupportedException e) {
            Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    static String escape(String s) {
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                default -> sb.append(c);
            }
        }
        return sb.toString();
    }

    static String unescape(String s) {
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) {
                char n = s.charAt(++i);
                switch (n) {
                    case 'n' -> sb.append('\n');
                    case 'r' -> sb.append('\r');
                    default -> sb.append(n);
                }
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }
}
