package dev.xenoverse.config;

import dev.xenoverse.core.ModuleManager;
import dev.xenoverse.util.Log;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Stream;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * Loads and saves everything under {@code config/xenoverse/}:
 * <ul>
 *   <li>{@code config.properties} - global client settings, favourites, recents, active profile</li>
 *   <li>{@code profiles/<name>.properties} - module states/settings and HUD layout ("extras")</li>
 * </ul>
 * Profiles can be exported to / imported from a single copy-paste-friendly text code ("XV1:...").
 */
public final class ConfigManager {
    public static final String DEFAULT_PROFILE = "default";
    public static final String EXPORT_PREFIX = "XV1:";
    private static final int FORMAT = 1;

    public record ImportResult(int applied, int skipped) {}

    private final Path mainFile;
    private final Path profilesDir;
    private final ClientSettings settings;
    private final ModuleManager modules;
    private final Map<String, String> extras = new TreeMap<>();
    private String activeProfile = DEFAULT_PROFILE;
    private volatile boolean dirty;

    public ConfigManager(Path dir, ClientSettings settings, ModuleManager modules) {
        this.mainFile = dir.resolve("config.properties");
        this.profilesDir = dir.resolve("profiles");
        this.settings = settings;
        this.modules = modules;
    }

    public void markDirty() { dirty = true; }
    public boolean isDirty() { return dirty; }
    public String activeProfile() { return activeProfile; }

    // ---- load / save -------------------------------------------------------------------------
    public synchronized void load() {
        Map<String, String> main = readQuietly(mainFile);
        settings.readFrom(main);
        modules.readUserState(main);
        String wanted = main.get("profile.active");
        activeProfile = isValidName(wanted) ? wanted : DEFAULT_PROFILE;
        loadProfileFile(activeProfile);
        dirty = false;
    }

    public synchronized void saveIfDirty() {
        if (dirty) save();
    }

    public synchronized void save() {
        try {
            Map<String, String> main = new TreeMap<>();
            main.put("meta.format", Integer.toString(FORMAT));
            main.put("profile.active", activeProfile);
            settings.writeTo(main);
            modules.writeUserState(main);
            PropertiesIO.writeAtomic(mainFile, PropertiesIO.write(main, "XenoVerse configuration"));
            PropertiesIO.writeAtomic(profileFile(activeProfile),
                PropertiesIO.write(snapshot(), "XenoVerse profile: " + activeProfile));
            dirty = false;
        } catch (IOException | RuntimeException e) {
            Log.error("Could not save the configuration", e);
        }
    }

    private Map<String, String> snapshot() {
        Map<String, String> out = new TreeMap<>();
        out.put("meta.format", Integer.toString(FORMAT));
        modules.writeProfileState(out);
        for (Map.Entry<String, String> e : extras.entrySet()) out.put("x." + e.getKey(), e.getValue());
        return out;
    }

    private Map<String, String> readQuietly(Path file) {
        if (!Files.isRegularFile(file)) return new TreeMap<>();
        try {
            return PropertiesIO.read(file);
        } catch (IOException | RuntimeException e) {
            Log.warn("Ignoring unreadable config file " + file.getFileName() + ": " + e.getMessage());
            return new TreeMap<>();
        }
    }

    private void loadProfileFile(String name) {
        Map<String, String> data = readQuietly(profileFile(name));
        applyProfileData(data);
    }

    private ImportResult applyProfileData(Map<String, String> data) {
        extras.clear();
        for (Map.Entry<String, String> e : data.entrySet()) {
            if (e.getKey().startsWith("x.")) extras.put(e.getKey().substring(2), e.getValue());
        }
        ModuleManager.StateReport report = modules.readProfileState(data);
        return new ImportResult(report.applied(), report.skipped());
    }

    // ---- extras (e.g. HUD element positions), stored inside the active profile ----------------
    public synchronized void putExtra(String key, String value) {
        if (key == null || !key.matches("[A-Za-z0-9._-]+")) throw new IllegalArgumentException("Bad key: " + key);
        extras.put(key, value);
        markDirty();
    }

    public synchronized String getExtra(String key, String fallback) {
        return extras.getOrDefault(key, fallback);
    }

    public synchronized void removeExtra(String key) {
        if (extras.remove(key) != null) markDirty();
    }

    // ---- profiles ----------------------------------------------------------------------------
    public static boolean isValidName(String name) {
        return name != null && name.matches("[A-Za-z0-9][A-Za-z0-9 _-]{0,31}") && name.equals(name.trim());
    }

    private Path profileFile(String name) {
        return profilesDir.resolve(name.toLowerCase(Locale.ROOT).replace(' ', '_') + ".properties");
    }

    /** Names of all saved profiles (always includes the active one). */
    public synchronized List<String> listProfiles() {
        List<String> names = new ArrayList<>();
        if (Files.isDirectory(profilesDir)) {
            try (Stream<Path> files = Files.list(profilesDir)) {
                files.map(p -> p.getFileName().toString())
                    .filter(n -> n.endsWith(".properties"))
                    .map(n -> n.substring(0, n.length() - ".properties".length()).replace('_', ' '))
                    .forEach(names::add);
            } catch (IOException e) {
                Log.warn("Could not list profiles: " + e.getMessage());
            }
        }
        if (names.stream().noneMatch(n -> n.equalsIgnoreCase(activeProfile))) names.add(activeProfile);
        names.sort(String.CASE_INSENSITIVE_ORDER);
        return names;
    }

    /** Saves the current state under a new name and makes it the active profile. */
    public synchronized void createProfile(String name) {
        requireValid(name);
        if (profileExists(name)) throw new IllegalArgumentException("A profile named '" + name + "' already exists");
        save();
        activeProfile = name;
        save();
    }

    public synchronized void switchProfile(String name) {
        requireValid(name);
        if (!profileExists(name)) throw new IllegalArgumentException("No profile named '" + name + "'");
        save();
        activeProfile = name;
        loadProfileFile(name);
        dirty = true;
        save();
    }

    public synchronized void deleteProfile(String name) {
        requireValid(name);
        if (name.equalsIgnoreCase(DEFAULT_PROFILE)) throw new IllegalArgumentException("The default profile cannot be deleted");
        if (name.equalsIgnoreCase(activeProfile)) throw new IllegalArgumentException("Switch to another profile first");
        try {
            Files.deleteIfExists(profileFile(name));
        } catch (IOException e) {
            Log.error("Could not delete profile " + name, e);
        }
    }

    private boolean profileExists(String name) {
        return listProfiles().stream().anyMatch(n -> n.equalsIgnoreCase(name));
    }

    private static void requireValid(String name) {
        if (!isValidName(name)) {
            throw new IllegalArgumentException("Profile names use letters, numbers, spaces, - and _ (max 32 characters)");
        }
    }

    // ---- export / import ---------------------------------------------------------------------
    /** One line of text containing the whole active profile; paste it to share or back it up. */
    public synchronized String exportCode() {
        try {
            byte[] raw = PropertiesIO.write(snapshot(), null).getBytes(StandardCharsets.UTF_8);
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            try (GZIPOutputStream gz = new GZIPOutputStream(bytes)) {
                gz.write(raw);
            }
            return EXPORT_PREFIX + Base64.getUrlEncoder().withoutPadding().encodeToString(bytes.toByteArray());
        } catch (IOException e) {
            throw new IllegalStateException("Export failed", e);
        }
    }

    /** Applies an exported code to the current profile. Throws IllegalArgumentException if invalid. */
    public synchronized ImportResult importCode(String code) {
        if (code == null) throw new IllegalArgumentException("Nothing to import");
        String trimmed = code.replaceAll("\\s+", "");
        if (!trimmed.startsWith(EXPORT_PREFIX)) throw new IllegalArgumentException("Not a XenoVerse export code");
        byte[] compressed;
        try {
            compressed = Base64.getUrlDecoder().decode(trimmed.substring(EXPORT_PREFIX.length()));
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("The code is damaged (bad characters)");
        }
        String text;
        try (GZIPInputStream gz = new GZIPInputStream(new ByteArrayInputStream(compressed))) {
            byte[] data = gz.readNBytes((int) PropertiesIO.MAX_BYTES + 1);
            if (data.length > PropertiesIO.MAX_BYTES) throw new IllegalArgumentException("The code is too large");
            text = new String(data, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new IllegalArgumentException("The code is damaged (cannot be unpacked)");
        }
        Map<String, String> data = PropertiesIO.parse(text);
        if (!data.containsKey("meta.format")) throw new IllegalArgumentException("Not a XenoVerse profile");
        ImportResult result = applyProfileData(data);
        dirty = true;
        save();
        return result;
    }
}
