package dev.xenoverse;

import dev.xenoverse.core.ModuleManager;

/**
 * Registers the built-in modules. Phase 1 ships the module framework only; the 50 modules
 * (10 categories x 5) are added in Phase 3, one category class at a time.
 */
final class BuiltinModules {
    private BuiltinModules() {}

    static void registerAll(ModuleManager modules) {
        // Intentionally empty in Phase 1: no fake modules.
    }
}
