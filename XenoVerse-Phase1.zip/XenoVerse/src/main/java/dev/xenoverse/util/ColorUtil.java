package dev.xenoverse.util;

/** ARGB colour helpers (0xAARRGGBB). Pure Java: no AWT, so it is safe on every launcher. */
public final class ColorUtil {
    private ColorUtil() {}

    public static int argb(int a, int r, int g, int b) {
        return (clamp255(a) << 24) | (clamp255(r) << 16) | (clamp255(g) << 8) | clamp255(b);
    }

    public static int alpha(int c) { return (c >>> 24) & 0xFF; }
    public static int red(int c)   { return (c >>> 16) & 0xFF; }
    public static int green(int c) { return (c >>> 8) & 0xFF; }
    public static int blue(int c)  { return c & 0xFF; }

    public static int withAlpha(int c, int a) {
        return (clamp255(a) << 24) | (c & 0x00FFFFFF);
    }

    /** Multiplies the existing alpha by {@code factor} (0..1). */
    public static int scaleAlpha(int c, double factor) {
        return withAlpha(c, (int) Math.round(alpha(c) * clamp01(factor)));
    }

    public static int lerp(int from, int to, double t) {
        t = clamp01(t);
        return argb(
            (int) Math.round(alpha(from) + (alpha(to) - alpha(from)) * t),
            (int) Math.round(red(from) + (red(to) - red(from)) * t),
            (int) Math.round(green(from) + (green(to) - green(from)) * t),
            (int) Math.round(blue(from) + (blue(to) - blue(from)) * t));
    }

    /** Opaque colour from hue/saturation/brightness, each 0..1 (hue wraps). */
    public static int hsb(float h, float s, float v) {
        h = h - (float) Math.floor(h);
        s = (float) clamp01(s);
        v = (float) clamp01(v);
        float r, g, b;
        if (s == 0f) {
            r = g = b = v;
        } else {
            float h6 = h * 6f;
            int sector = (int) Math.floor(h6);
            float f = h6 - sector;
            float p = v * (1f - s);
            float q = v * (1f - s * f);
            float t = v * (1f - s * (1f - f));
            switch (sector) {
                case 0 -> { r = v; g = t; b = p; }
                case 1 -> { r = q; g = v; b = p; }
                case 2 -> { r = p; g = v; b = t; }
                case 3 -> { r = p; g = q; b = v; }
                case 4 -> { r = t; g = p; b = v; }
                default -> { r = v; g = p; b = q; }
            }
        }
        return argb(255, Math.round(r * 255f), Math.round(g * 255f), Math.round(b * 255f));
    }

    /** Parses "#RRGGBB" or "#AARRGGBB" (the '#' is optional). Returns null if invalid. */
    public static Integer parseHex(String text) {
        if (text == null) return null;
        String s = text.trim();
        if (s.startsWith("#")) s = s.substring(1);
        if (s.length() != 6 && s.length() != 8) return null;
        for (int i = 0; i < s.length(); i++) {
            if (Character.digit(s.charAt(i), 16) < 0) return null;
        }
        long v = Long.parseLong(s, 16);
        return s.length() == 6 ? (int) (0xFF000000L | v) : (int) v;
    }

    public static String toHex(int c, boolean withAlpha) {
        return withAlpha
            ? String.format("#%08X", c)
            : String.format("#%06X", c & 0xFFFFFF);
    }

    public static double clamp01(double v) {
        return v < 0 ? 0 : Math.min(v, 1);
    }

    private static int clamp255(int v) {
        return v < 0 ? 0 : Math.min(v, 255);
    }
}
