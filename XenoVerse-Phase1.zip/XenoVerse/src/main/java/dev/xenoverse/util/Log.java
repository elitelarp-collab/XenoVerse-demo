package dev.xenoverse.util;

import java.lang.System.Logger;
import java.lang.System.Logger.Level;

/** Tiny logging facade so the core code has no dependency on a logging library. */
public final class Log {
    private static final Logger LOGGER = System.getLogger("XenoVerse");

    private Log() {}

    public static void info(String message) {
        LOGGER.log(Level.INFO, "[XenoVerse] " + message);
    }

    public static void warn(String message) {
        LOGGER.log(Level.WARNING, "[XenoVerse] " + message);
    }

    public static void error(String message, Throwable error) {
        LOGGER.log(Level.ERROR, "[XenoVerse] " + message, error);
    }
}
