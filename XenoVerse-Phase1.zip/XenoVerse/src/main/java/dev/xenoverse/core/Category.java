package dev.xenoverse.core;

/** The ten module categories shown in the mod menu. */
public enum Category {
    HUD("HUD", "hud", "On-screen information elements"),
    PVP("PvP", "pvp", "Combat feedback and helpers"),
    PERFORMANCE("Performance", "performance", "Client-side optimisation"),
    VISUALS("Visuals", "visuals", "Rendering and appearance tweaks"),
    MOVEMENT("Movement", "movement", "Movement quality-of-life"),
    WORLD("World", "world", "World and environment display"),
    SOCIAL("Social", "social", "Friends, chat and server info"),
    INVENTORY("Inventory", "inventory", "Inventory and item helpers"),
    CUSTOMIZATION("Customization", "customization", "Personalise the client"),
    UTILITIES("Utilities", "utilities", "Handy everyday tools");

    private final String displayName;
    private final String id;
    private final String description;

    Category(String displayName, String id, String description) {
        this.displayName = displayName;
        this.id = id;
        this.description = description;
    }

    public String displayName() { return displayName; }
    public String id() { return id; }
    public String description() { return description; }

    /** Path of this category's icon inside the mod's assets (namespace "xenoverse"). */
    public String iconPath() { return "textures/gui/icons/category_" + id + ".png"; }

    public static Category fromId(String id) {
        for (Category c : values()) {
            if (c.id.equalsIgnoreCase(id)) return c;
        }
        return null;
    }
}
