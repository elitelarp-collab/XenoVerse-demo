package dev.xenoverse.core.setting;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/**
 * A single configurable value. Subclasses define validation ({@link #coerce}) and how the value is
 * stored in the config file ({@link #serialize}/{@link #deserialize}).
 */
public abstract class Setting<T> {
    private final String key;
    private final String name;
    private final String description;
    private final T defaultValue;
    protected T value;
    private BooleanSupplier visibility = () -> true;
    private final List<Consumer<T>> listeners = new ArrayList<>();

    protected Setting(String key, String name, String description, T defaultValue) {
        if (key == null || !key.matches("[a-z0-9_]+")) {
            throw new IllegalArgumentException("Invalid setting key (use a-z, 0-9, _): " + key);
        }
        this.key = key;
        this.name = name;
        this.description = description == null ? "" : description;
        this.defaultValue = defaultValue;
        this.value = defaultValue;
    }

    public final String key() { return key; }
    public final String name() { return name; }
    public final String description() { return description; }
    public final T get() { return value; }
    public final T getDefault() { return defaultValue; }
    public final boolean isDefault() { return Objects.equals(value, defaultValue); }

    /** Validates and stores a value. Returns true if the value actually changed. */
    public final boolean set(T newValue) {
        T coerced = coerce(newValue);
        if (Objects.equals(coerced, value)) return false;
        value = coerced;
        for (Consumer<T> listener : new ArrayList<>(listeners)) {
            listener.accept(coerced);
        }
        return true;
    }

    public final void reset() { set(defaultValue); }

    public final void addListener(Consumer<T> listener) { listeners.add(listener); }

    /** Hide this setting in the UI unless the condition is true (e.g. a sub-option of a toggle). */
    public final void visibleWhen(BooleanSupplier condition) { this.visibility = condition; }
    public final boolean isVisible() { return visibility.getAsBoolean(); }

    /** Returns a valid value for {@code v}; must never throw. */
    protected abstract T coerce(T v);

    public abstract String serialize();

    /** Parses and applies a stored value. Returns false (keeping the old value) if it is invalid. */
    public abstract boolean deserialize(String text);
}
