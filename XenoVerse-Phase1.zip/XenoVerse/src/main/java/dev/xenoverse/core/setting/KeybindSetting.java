package dev.xenoverse.core.setting;

/** A keyboard key stored as a GLFW key code, or {@link #NONE}. */
public final class KeybindSetting extends Setting<Integer> {
    public static final int NONE = -1;

    public KeybindSetting(String key, String name, String description, int defaultKey) {
        super(key, name, description, defaultKey < 0 ? NONE : defaultKey);
    }

    public boolean isBound() { return value >= 0; }
    public String keyName() { return KeyNames.name(value); }

    @Override protected Integer coerce(Integer v) {
        if (v == null) return value;
        return v < 0 ? NONE : v;
    }

    @Override public String serialize() { return isBound() ? Integer.toString(value) : "none"; }

    @Override public boolean deserialize(String text) {
        String t = text.trim();
        if (t.equalsIgnoreCase("none")) { set(NONE); return true; }
        try {
            set(Integer.parseInt(t));
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
