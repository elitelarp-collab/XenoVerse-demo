package dev.xenoverse.core.setting;

/** Single-line text with a maximum length (e.g. a custom name tag). */
public final class StringSetting extends Setting<String> {
    private final int maxLength;

    public StringSetting(String key, String name, String description, String defaultValue, int maxLength) {
        super(key, name, description, clean(defaultValue, maxLength));
        this.maxLength = maxLength;
    }

    private static String clean(String s, int maxLength) {
        if (s == null) return "";
        String oneLine = s.replace('\n', ' ').replace('\r', ' ');
        return oneLine.length() > maxLength ? oneLine.substring(0, maxLength) : oneLine;
    }

    public int maxLength() { return maxLength; }

    @Override protected String coerce(String v) { return v == null ? value : clean(v, maxLength); }

    @Override public String serialize() { return value; }

    @Override public boolean deserialize(String text) {
        set(text);
        return true;
    }
}
