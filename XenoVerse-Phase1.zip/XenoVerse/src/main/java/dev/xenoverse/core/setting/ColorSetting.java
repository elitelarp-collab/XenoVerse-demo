package dev.xenoverse.core.setting;

import dev.xenoverse.util.ColorUtil;

/** A colour stored as 0xAARRGGBB. Without alpha support the colour is always fully opaque. */
public final class ColorSetting extends Setting<Integer> {
    private final boolean allowAlpha;

    public ColorSetting(String key, String name, String description, int defaultArgb, boolean allowAlpha) {
        super(key, name, description, fix(defaultArgb, allowAlpha));
        this.allowAlpha = allowAlpha;
    }

    private static int fix(int argb, boolean allowAlpha) {
        return allowAlpha ? argb : (0xFF000000 | argb);
    }

    public boolean allowsAlpha() { return allowAlpha; }
    public int argb() { return value; }
    public int rgb() { return value & 0xFFFFFF; }
    public int alpha() { return ColorUtil.alpha(value); }

    @Override protected Integer coerce(Integer v) { return v == null ? value : fix(v, allowAlpha); }

    @Override public String serialize() { return ColorUtil.toHex(value, allowAlpha); }

    @Override public boolean deserialize(String text) {
        Integer parsed = ColorUtil.parseHex(text);
        if (parsed == null) return false;
        set(parsed);
        return true;
    }
}
