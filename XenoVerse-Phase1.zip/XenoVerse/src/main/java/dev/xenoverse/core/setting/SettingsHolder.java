package dev.xenoverse.core.setting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Anything that owns an ordered list of settings (a module, or the global client settings). */
public abstract class SettingsHolder {
    private final Map<String, Setting<?>> settings = new LinkedHashMap<>();

    /** Registers a setting and returns it, so subclasses can write {@code speed = add(new ...)}. */
    protected final <S extends Setting<?>> S add(S setting) {
        if (settings.putIfAbsent(setting.key(), setting) != null) {
            throw new IllegalStateException("Duplicate setting key: " + setting.key());
        }
        return setting;
    }

    public final List<Setting<?>> getSettings() {
        return Collections.unmodifiableList(new ArrayList<>(settings.values()));
    }

    public final Setting<?> getSetting(String key) { return settings.get(key); }

    public final void resetSettings() {
        for (Setting<?> setting : settings.values()) setting.reset();
    }
}
