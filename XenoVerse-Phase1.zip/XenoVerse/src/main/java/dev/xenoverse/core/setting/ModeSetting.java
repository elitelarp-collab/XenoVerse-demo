package dev.xenoverse.core.setting;

import java.util.List;

/** One choice out of a fixed list of options (a dropdown / segmented control). */
public final class ModeSetting extends Setting<String> {
    private final List<String> options;

    public ModeSetting(String key, String name, String description, String defaultValue, String... options) {
        super(key, name, description, canonical(defaultValue, options));
        this.options = List.of(options);
    }

    private static String canonical(String wanted, String[] options) {
        if (options == null || options.length == 0) throw new IllegalArgumentException("A mode needs options");
        for (String option : options) {
            if (option.equalsIgnoreCase(wanted)) return option;
        }
        return options[0];
    }

    public List<String> options() { return options; }
    public int index() { return options.indexOf(value); }
    public boolean is(String option) { return value.equalsIgnoreCase(option); }

    public void cycle() { set(options.get((index() + 1) % options.size())); }
    public void cycleBack() { set(options.get((index() - 1 + options.size()) % options.size())); }

    @Override protected String coerce(String v) {
        if (v == null) return value;
        for (String option : options) {
            if (option.equalsIgnoreCase(v)) return option;
        }
        return value;
    }

    @Override public String serialize() { return value; }

    @Override public boolean deserialize(String text) {
        for (String option : options) {
            if (option.equalsIgnoreCase(text)) { set(option); return true; }
        }
        return false;
    }
}
