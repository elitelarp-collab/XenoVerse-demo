package dev.xenoverse.core;

import dev.xenoverse.core.setting.KeybindSetting;
import dev.xenoverse.core.setting.ModeSetting;
import dev.xenoverse.core.setting.SettingsHolder;
import dev.xenoverse.util.Log;

import java.util.List;
import java.util.Locale;

/**
 * Base class of every XenoVerse module. A module has an id, a category, a description, an enabled
 * flag, a keybind and any number of settings. Override {@link #onEnable()}, {@link #onDisable()}
 * and {@link #onTick()} to give it behaviour.
 *
 * <p>Safety: if a module throws an exception it is switched off and logged instead of crashing the
 * game.</p>
 */
public abstract class Module extends SettingsHolder {
    private final String id;
    private final String name;
    private final String description;
    private final Category category;
    private final List<String> tags;

    private final KeybindSetting keybind =
        new KeybindSetting("keybind", "Keybind", "Key that switches this module", KeybindSetting.NONE);
    private final ModeSetting bindMode =
        new ModeSetting("bind_mode", "Bind mode", "Toggle: press to switch. Hold: active while held.", "Toggle", "Toggle", "Hold");

    private boolean defaultEnabled;
    private boolean enabled;
    private boolean favorite;
    private long lastUsedMillis;
    private ModuleManager manager;

    protected Module(String id, String name, String description, Category category, String... tags) {
        if (id == null || !id.matches("[a-z0-9_]+")) {
            throw new IllegalArgumentException("Invalid module id (use a-z, 0-9, _): " + id);
        }
        this.id = id;
        this.name = name;
        this.description = description == null ? "" : description;
        this.category = category;
        String[] lowered = tags == null ? new String[0] : tags.clone();
        for (int i = 0; i < lowered.length; i++) lowered[i] = lowered[i].toLowerCase(Locale.ROOT);
        this.tags = List.of(lowered);
    }

    // ---- identity ----------------------------------------------------------------------------
    public final String id() { return id; }
    public final String name() { return name; }
    public final String description() { return description; }
    public final Category category() { return category; }
    public final List<String> tags() { return tags; }

    // ---- state -------------------------------------------------------------------------------
    public final boolean isEnabled() { return enabled; }
    public final boolean isFavorite() { return favorite; }
    public final long lastUsedMillis() { return lastUsedMillis; }
    public final KeybindSetting keybind() { return keybind; }
    public final ModeSetting bindMode() { return bindMode; }
    public final boolean isHoldMode() { return bindMode.is("Hold"); }

    /** Call from the constructor if the module should start switched on. */
    protected final void setDefaultEnabled(boolean value) {
        this.defaultEnabled = value;
        this.enabled = value;
    }

    public final boolean isDefaultEnabled() { return defaultEnabled; }

    public final void toggle() { setEnabled(!enabled); }

    public final void setEnabled(boolean on) {
        if (enabled == on) return;
        enabled = on;
        try {
            if (on) onEnable(); else onDisable();
        } catch (RuntimeException e) {
            Log.error("Module '" + id + "' failed while " + (on ? "enabling" : "disabling") + "; switching it off", e);
            enabled = false;
        }
        if (manager != null) manager.onToggled(this);
    }

    final void setFavoriteInternal(boolean value) { this.favorite = value; }
    final void setLastUsed(long millis) { this.lastUsedMillis = millis; }
    final void attach(ModuleManager manager) { this.manager = manager; }

    /** Called every client tick while enabled. Exceptions switch the module off. */
    public final void tick() {
        if (!enabled) return;
        try {
            onTick();
        } catch (RuntimeException e) {
            Log.error("Module '" + id + "' threw during tick; switching it off", e);
            enabled = false;
            try { onDisable(); } catch (RuntimeException ignored) { /* already faulted */ }
            if (manager != null) manager.onToggled(this);
        }
    }

    // ---- hooks for subclasses ----------------------------------------------------------------
    protected void onEnable() {}
    protected void onDisable() {}
    protected void onTick() {}
}
