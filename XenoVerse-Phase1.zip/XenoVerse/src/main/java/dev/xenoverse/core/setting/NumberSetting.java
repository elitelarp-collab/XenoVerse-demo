package dev.xenoverse.core.setting;

import java.math.BigDecimal;

/** A number between {@code min} and {@code max} that snaps to multiples of {@code step}. */
public final class NumberSetting extends Setting<Double> {
    private final double min;
    private final double max;
    private final double step;

    public NumberSetting(String key, String name, String description,
                         double defaultValue, double min, double max, double step) {
        super(key, name, description, normalize(defaultValue, min, max, step));
        this.min = min;
        this.max = max;
        this.step = step;
    }

    private static double normalize(double v, double min, double max, double step) {
        if (!(min < max) || !(step > 0)) {
            throw new IllegalArgumentException("Invalid number range: " + min + ".." + max + " step " + step);
        }
        if (Double.isNaN(v)) v = min;
        double clamped = Math.max(min, Math.min(max, v));
        double snapped = min + Math.round((clamped - min) / step) * step;
        snapped = Math.max(min, Math.min(max, snapped));
        return Math.round(snapped * 1e6) / 1e6;
    }

    public double min() { return min; }
    public double max() { return max; }
    public double step() { return step; }

    public double asDouble() { return value; }
    public int asInt() { return (int) Math.round(value); }
    public float asFloat() { return value.floatValue(); }

    /** Position of the value on the slider, 0..1. */
    public double fraction() { return (value - min) / (max - min); }

    public void setFraction(double f) {
        double clamped = Math.max(0, Math.min(1, f));
        set(min + clamped * (max - min));
    }

    @Override protected Double coerce(Double v) { return v == null ? value : normalize(v, min, max, step); }

    @Override public String serialize() {
        return BigDecimal.valueOf(value).stripTrailingZeros().toPlainString();
    }

    @Override public boolean deserialize(String text) {
        try {
            double parsed = Double.parseDouble(text.trim());
            if (Double.isNaN(parsed) || Double.isInfinite(parsed)) return false;
            set(parsed);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
