package dev.xenoverse.core;

import dev.xenoverse.core.setting.Setting;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.function.IntPredicate;

/** Registry of all modules: lookup, search, favourites, recents, keybinds and state (de)serialisation. */
public final class ModuleManager {
    private static final int MAX_RECENT = 8;

    /** How many keys of a stored profile were applied or ignored. */
    public record StateReport(int applied, int skipped) {}

    private final Map<String, Module> modules = new LinkedHashMap<>();
    private final Deque<String> recent = new ArrayDeque<>();
    private final Set<Integer> heldKeys = new HashSet<>();
    private Runnable dirtyCallback = () -> {};
    private boolean loading;

    public void setDirtyCallback(Runnable callback) {
        this.dirtyCallback = callback == null ? () -> {} : callback;
    }

    // ---- registration & lookup ---------------------------------------------------------------
    public void register(Module module) {
        if (modules.putIfAbsent(module.id(), module) != null) {
            throw new IllegalStateException("Duplicate module id: " + module.id());
        }
        module.attach(this);
        Runnable dirty = this::markDirty;
        for (Setting<?> setting : module.getSettings()) setting.addListener(v -> dirty.run());
        module.keybind().addListener(v -> dirty.run());
        module.bindMode().addListener(v -> dirty.run());
    }

    public List<Module> all() { return Collections.unmodifiableList(new ArrayList<>(modules.values())); }
    public Module get(String id) { return modules.get(id); }

    public List<Module> inCategory(Category category) {
        List<Module> out = new ArrayList<>();
        for (Module m : modules.values()) if (m.category() == category) out.add(m);
        return out;
    }

    public List<Module> enabled() {
        List<Module> out = new ArrayList<>();
        for (Module m : modules.values()) if (m.isEnabled()) out.add(m);
        return out;
    }

    // ---- search ------------------------------------------------------------------------------
    /** Searches names, ids, tags, categories and descriptions. Empty query lists everything. */
    public List<Module> search(String query, Category categoryFilter) {
        String[] tokens = query == null || query.isBlank()
            ? new String[0]
            : query.toLowerCase(Locale.ROOT).trim().split("\\s+");
        List<Scored> hits = new ArrayList<>();
        for (Module m : modules.values()) {
            if (categoryFilter != null && m.category() != categoryFilter) continue;
            int score = 0;
            boolean matchesAll = true;
            for (String token : tokens) {
                int s = scoreToken(m, token);
                if (s == 0) { matchesAll = false; break; }
                score += s;
            }
            if (!matchesAll) continue;
            if (m.isFavorite()) score += 5;
            hits.add(new Scored(m, score));
        }
        hits.sort(Comparator
            .comparingInt((Scored s) -> -s.score)
            .thenComparingInt(s -> s.module.category().ordinal())
            .thenComparing(s -> s.module.name().toLowerCase(Locale.ROOT)));
        List<Module> out = new ArrayList<>(hits.size());
        for (Scored s : hits) out.add(s.module);
        return out;
    }

    private record Scored(Module module, int score) {}

    private static int scoreToken(Module m, String token) {
        String name = m.name().toLowerCase(Locale.ROOT);
        if (name.equals(token)) return 100;
        if (name.startsWith(token)) return 80;
        if (name.contains(" " + token)) return 60;
        if (name.contains(token)) return 50;
        if (m.id().contains(token)) return 40;
        for (String tag : m.tags()) if (tag.contains(token)) return 35;
        if (m.category().displayName().toLowerCase(Locale.ROOT).contains(token)) return 25;
        if (m.description().toLowerCase(Locale.ROOT).contains(token)) return 15;
        return 0;
    }

    // ---- favourites & recents ----------------------------------------------------------------
    public void setFavorite(Module module, boolean favorite) {
        if (module.isFavorite() == favorite) return;
        module.setFavoriteInternal(favorite);
        markDirty();
    }

    public List<Module> favorites() {
        List<Module> out = new ArrayList<>();
        for (Module m : modules.values()) if (m.isFavorite()) out.add(m);
        return out;
    }

    /** Marks a module as just used (toggled or opened); most recent first, at most 8 kept. */
    public void touch(Module module) {
        recent.remove(module.id());
        recent.addFirst(module.id());
        while (recent.size() > MAX_RECENT) recent.removeLast();
        module.setLastUsed(System.currentTimeMillis());
        markDirty();
    }

    public List<Module> recents() {
        List<Module> out = new ArrayList<>();
        for (String id : recent) {
            Module m = modules.get(id);
            if (m != null) out.add(m);
        }
        return out;
    }

    // ---- ticking & keybinds ------------------------------------------------------------------
    public void tick() {
        for (Module m : modules.values()) m.tick();
    }

    /**
     * Checks every bound key and toggles / holds modules. {@code isDown} answers "is this GLFW key
     * currently pressed?". Pass {@code inputAllowed = false} while a screen is open or chat is typing.
     */
    public void pollKeys(IntPredicate isDown, boolean inputAllowed) {
        Set<Integer> nowDown = new HashSet<>();
        for (Module m : modules.values()) {
            int key = m.keybind().get();
            if (key >= 0 && inputAllowed && isDown.test(key)) nowDown.add(key);
        }
        for (Module m : modules.values()) {
            int key = m.keybind().get();
            if (key < 0) continue;
            boolean down = nowDown.contains(key);
            boolean wasDown = heldKeys.contains(key);
            if (m.isHoldMode()) {
                if (down != wasDown) m.setEnabled(down);
            } else if (down && !wasDown) {
                m.toggle();
            }
        }
        heldKeys.clear();
        heldKeys.addAll(nowDown);
    }

    // ---- state (de)serialisation -------------------------------------------------------------
    void onToggled(Module module) {
        if (!loading) touch(module);
        markDirty();
    }

    private void markDirty() {
        if (!loading) dirtyCallback.run();
    }

    /** Per-profile state: enabled flag, keybind and settings of every module. */
    public void writeProfileState(Map<String, String> out) {
        for (Module m : modules.values()) {
            String p = "module." + m.id() + ".";
            out.put(p + "enabled", Boolean.toString(m.isEnabled()));
            out.put(p + "keybind", m.keybind().serialize());
            out.put(p + "bind_mode", m.bindMode().serialize());
            for (Setting<?> s : m.getSettings()) out.put(p + "s." + s.key(), s.serialize());
        }
    }

    /** Resets every module to its defaults, then applies whatever {@code in} contains. */
    public StateReport readProfileState(Map<String, String> in) {
        int applied = 0;
        Set<String> consumed = new HashSet<>();
        loading = true;
        try {
            for (Module m : modules.values()) {
                m.resetSettings();
                m.keybind().reset();
                m.bindMode().reset();
                String p = "module." + m.id() + ".";

                for (Setting<?> s : m.getSettings()) {
                    String key = p + "s." + s.key();
                    String v = in.get(key);
                    if (v != null) {
                        consumed.add(key);
                        if (s.deserialize(v)) applied++;
                    }
                }
                String v = in.get(p + "keybind");
                if (v != null) { consumed.add(p + "keybind"); if (m.keybind().deserialize(v)) applied++; }
                v = in.get(p + "bind_mode");
                if (v != null) { consumed.add(p + "bind_mode"); if (m.bindMode().deserialize(v)) applied++; }
                v = in.get(p + "enabled");
                if (v != null) consumed.add(p + "enabled");
                boolean wantEnabled = v != null ? "true".equalsIgnoreCase(v) : m.isDefaultEnabled();
                if (v != null) applied++;
                m.setEnabled(wantEnabled);
            }
        } finally {
            loading = false;
        }
        int moduleKeys = 0;
        for (String key : in.keySet()) if (key.startsWith("module.")) moduleKeys++;
        return new StateReport(applied, Math.max(0, moduleKeys - consumed.size()));
    }

    /** Per-user state that is NOT part of a profile: favourites and recents. */
    public void writeUserState(Map<String, String> out) {
        StringBuilder fav = new StringBuilder();
        for (Module m : modules.values()) {
            if (m.isFavorite()) { if (fav.length() > 0) fav.append(','); fav.append(m.id()); }
        }
        out.put("user.favorites", fav.toString());
        out.put("user.recent", String.join(",", recent));
    }

    public void readUserState(Map<String, String> in) {
        loading = true;
        try {
            Set<String> favs = new HashSet<>();
            String f = in.get("user.favorites");
            if (f != null && !f.isBlank()) Collections.addAll(favs, f.split(","));
            for (Module m : modules.values()) m.setFavoriteInternal(favs.contains(m.id()));

            recent.clear();
            String r = in.get("user.recent");
            if (r != null && !r.isBlank()) {
                for (String id : r.split(",")) {
                    if (modules.containsKey(id) && !recent.contains(id) && recent.size() < MAX_RECENT) recent.addLast(id);
                }
            }
        } finally {
            loading = false;
        }
    }
}
