package dev.xenoverse.core.setting;

public final class BooleanSetting extends Setting<Boolean> {
    public BooleanSetting(String key, String name, String description, boolean defaultValue) {
        super(key, name, description, defaultValue);
    }

    public boolean isOn() { return value; }
    public void toggle() { set(!value); }

    @Override protected Boolean coerce(Boolean v) { return v == null ? value : v; }

    @Override public String serialize() { return value ? "true" : "false"; }

    @Override public boolean deserialize(String text) {
        if ("true".equalsIgnoreCase(text)) { set(true); return true; }
        if ("false".equalsIgnoreCase(text)) { set(false); return true; }
        return false;
    }
}
