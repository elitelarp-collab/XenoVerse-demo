#!/usr/bin/env python3
"""Generates XenoVerse's logo, mod icon and the ten category icons (needs Pillow + numpy).
Run from the project root:  python3 tools/generate_assets.py
"""
import glob, math, os
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

OUT = "src/main/resources/assets/xenoverse"
os.makedirs(f"{OUT}/textures/gui/icons", exist_ok=True)

NAVY = (8, 16, 44)
DEEP = (14, 36, 104)
BLUE = (30, 144, 255)
CYAN = (92, 220, 255)

def lerp(a, b, t):
    return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(3))

def diag_gradient(size, c0, c1):
    y, x = np.mgrid[0:size, 0:size]
    t = ((x + y) / (2.0 * (size - 1)))[..., None]
    arr = np.array(c0, float) * (1 - t) + np.array(c1, float) * t
    return Image.fromarray(arr.astype("uint8"), "RGB").convert("RGBA")

def rounded_mask(size, radius):
    m = Image.new("L", (size, size), 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, size - 1, size - 1), radius, fill=255)
    return m

def draw_x(draw, s, color, width, margin):
    a, b = margin, s - margin
    draw.line((a, a, b, b), fill=color, width=width)
    draw.line((b, a, a, b), fill=color, width=width)
    r = width // 2
    for (x, y) in ((a, a), (b, b), (b, a), (a, b)):
        draw.ellipse((x - r, y - r, x + r, y + r), fill=color)

def x_mark(size):
    """The XenoVerse mark: a glowing X on a navy-to-electric-blue rounded square."""
    S = size * 4
    base = diag_gradient(S, NAVY, DEEP)
    # electric glow in the lower-right
    glow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    ImageDraw.Draw(glow).ellipse((S * 0.35, S * 0.35, S * 1.15, S * 1.15), fill=BLUE + (150,))
    glow = glow.filter(ImageFilter.GaussianBlur(S * 0.12))
    base = Image.alpha_composite(base, glow)
    # soft X glow
    xg = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    draw_x(ImageDraw.Draw(xg), S, CYAN + (255,), int(S * 0.17), int(S * 0.27))
    base = Image.alpha_composite(base, xg.filter(ImageFilter.GaussianBlur(S * 0.05)))
    # crisp X (gradient white -> cyan)
    xm = Image.new("L", (S, S), 0)
    draw_x(ImageDraw.Draw(xm), S, 255, int(S * 0.115), int(S * 0.27))
    grad = diag_gradient(S, (255, 255, 255), CYAN)
    base.paste(grad, (0, 0), xm)
    # rim light
    rim = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    ImageDraw.Draw(rim).rounded_rectangle((S * 0.01, S * 0.01, S * 0.99, S * 0.99), int(S * 0.22),
                                          outline=BLUE + (200,), width=max(2, int(S * 0.02)))
    base = Image.alpha_composite(base, rim)
    base.putalpha(rounded_mask(S, int(S * 0.22)))
    return base.resize((size, size), Image.LANCZOS)

def find_font():
    for pat in ("/usr/share/fonts/opentype/inter/InterDisplay-Bold.otf",
                "/usr/share/fonts/opentype/inter/Inter-Bold.otf",
                "/usr/share/fonts/**/*Bold*.ttf", "/usr/share/fonts/**/*Bold*.otf"):
        hits = glob.glob(pat, recursive=True)
        if hits:
            return hits[0]
    return None

def logo(w=860, h=160):
    S = 3
    img = Image.new("RGBA", (w * S, h * S), (0, 0, 0, 0))
    mark = x_mark(h * S - 16 * S)
    img.alpha_composite(mark, (8 * S, 8 * S))
    font_path = find_font()
    font = ImageFont.truetype(font_path, int(h * S * 0.50)) if font_path else ImageFont.load_default()
    text, spacing = "XENOVERSE", int(h * S * 0.045)
    widths = [font.getlength(ch) for ch in text]
    total = int(sum(widths) + spacing * (len(text) - 1))
    mask = Image.new("L", img.size, 0)
    md = ImageDraw.Draw(mask)
    x0, y = (h * S) + 12 * S, int(h * S * 0.24)
    x = x0
    for ch, cw in zip(text, widths):
        md.text((x, y), ch, font=font, fill=255)
        x += cw + spacing
    gw = max(total, 1)
    gy, gx = np.mgrid[0:img.size[1], 0:img.size[0]]
    t = np.clip((gx - x0) / gw, 0, 1)[..., None]
    c0, c1 = np.array((255, 255, 255), float), np.array(BLUE, float)
    arr = (c0 * (1 - t) + c1 * t).astype("uint8")
    gradient = Image.fromarray(arr, "RGB").convert("RGBA")
    glow = Image.new("RGBA", img.size, BLUE + (0,))
    glow.putalpha(mask.filter(ImageFilter.GaussianBlur(10 * S)).point(lambda v: int(v * 0.55)))
    img = Image.alpha_composite(img, glow)
    img.paste(gradient, (0, 0), mask)
    return img.resize((w, h), Image.LANCZOS)

# ---- category icons: white glyphs on transparent, meant to be tinted in code ------------------
W = (255, 255, 255, 255)
CLEAR = (0, 0, 0, 0)

def canvas():
    img = Image.new("RGBA", (512, 512), CLEAR)
    return img, ImageDraw.Draw(img)

def thick(d, pts, w):
    d.line(pts, fill=W, width=w, joint="curve")
    r = w // 2
    for (x, y) in (pts[0], pts[-1]):
        d.ellipse((x - r, y - r, x + r, y + r), fill=W)

def icon_hud():
    img, d = canvas()
    d.rounded_rectangle((52, 92, 460, 420), 48, outline=W, width=34)
    d.rounded_rectangle((120, 160, 250, 200), 14, fill=W)
    d.rounded_rectangle((120, 236, 340, 276), 14, fill=W)
    d.rounded_rectangle((120, 312, 200, 352), 14, fill=W)
    return img

def icon_pvp():
    img, d = canvas()
    # two swords: blades from the top corners down to hilts at the bottom corners
    thick(d, [(88, 88), (404, 404)], 36)
    thick(d, [(424, 88), (108, 404)], 36)
    # crossguards sit near the hilts
    thick(d, [(268, 372), (372, 268)], 28)
    thick(d, [(140, 268), (244, 372)], 28)
    # pommels
    d.ellipse((384, 384, 456, 456), fill=W)
    d.ellipse((56, 384, 128, 456), fill=W)
    return img

def icon_performance():
    img, d = canvas()
    d.polygon([(312, 32), (130, 290), (240, 290), (196, 480), (390, 214), (274, 214)], fill=W)
    return img

def icon_visuals():
    img, d = canvas()
    lens = [(30, 256)]
    for i in range(0, 101):
        t = i / 100.0
        x = 30 + 452 * t
        y = 256 - 150 * math.sin(math.pi * t)
        lens.append((x, y))
    bottom = [(30 + 452 * (1 - i / 100.0), 256 + 150 * math.sin(math.pi * (1 - i / 100.0))) for i in range(0, 101)]
    d.line(lens[1:] + bottom, fill=W, width=34, joint="curve")
    d.ellipse((186, 186, 326, 326), fill=W)
    d.ellipse((232, 232, 270, 270), fill=CLEAR)
    return img

def icon_movement():
    img, d = canvas()
    thick(d, [(130, 110), (276, 256), (130, 402)], 44)
    thick(d, [(264, 110), (410, 256), (264, 402)], 44)
    return img

def icon_world():
    img, d = canvas()
    d.ellipse((48, 48, 464, 464), outline=W, width=30)
    d.ellipse((160, 48, 352, 464), outline=W, width=24)
    d.line((48, 256, 464, 256), fill=W, width=24)
    d.line((90, 150, 422, 150), fill=W, width=22)
    d.line((90, 362, 422, 362), fill=W, width=22)
    return img

def icon_social():
    img, d = canvas()
    # back person
    d.ellipse((290, 90, 400, 200), fill=W)
    d.pieslice((250, 222, 440, 440), 180, 360, fill=W)
    d.rectangle((250, 331, 440, 440), fill=W)
    # front person with a clear outline so the two read as separate
    d.ellipse((72, 82, 236, 246), fill=CLEAR)
    d.pieslice((32, 252, 276, 520), 180, 360, fill=CLEAR)
    d.ellipse((92, 102, 216, 226), fill=W)
    d.pieslice((52, 272, 256, 500), 180, 360, fill=W)
    d.rectangle((52, 386, 256, 440), fill=W)
    return img

def icon_inventory():
    img, d = canvas()
    for (x, y) in ((64, 64), (282, 64), (64, 282), (282, 282)):
        d.rounded_rectangle((x, y, x + 166, y + 166), 30, fill=W)
    d.rounded_rectangle((312, 96, 418, 202), 16, fill=CLEAR)
    d.rounded_rectangle((330, 114, 400, 184), 10, fill=W)
    return img

def icon_customization():
    img, d = canvas()
    for y, kx in ((120, 330), (256, 190), (392, 380)):
        d.line((56, y, 456, y), fill=W, width=26)
        d.ellipse((kx - 62, y - 62, kx + 62, y + 62), fill=CLEAR)
        d.ellipse((kx - 42, y - 42, kx + 42, y + 42), fill=W)
    return img

def icon_utilities():
    img, d = canvas()
    cx = cy = 256
    d.ellipse((cx - 150, cy - 150, cx + 150, cy + 150), fill=W)
    for k in range(8):
        a = math.radians(k * 45)
        ca, sa = math.cos(a), math.sin(a)
        r0, r1, hw = 130, 220, 38
        pts = []
        for (r, o) in ((r0, -hw), (r1, -hw), (r1, hw), (r0, hw)):
            pts.append((cx + r * ca - o * sa, cy + r * sa + o * ca))
        d.polygon(pts, fill=W)
    d.ellipse((cx - 76, cy - 76, cx + 76, cy + 76), fill=CLEAR)
    return img

ICONS = {"hud": icon_hud, "pvp": icon_pvp, "performance": icon_performance, "visuals": icon_visuals,
         "movement": icon_movement, "world": icon_world, "social": icon_social,
         "inventory": icon_inventory, "customization": icon_customization, "utilities": icon_utilities}

x_mark(128).save(f"{OUT}/icon.png")
logo().save(f"{OUT}/textures/gui/logo.png")
x_mark(256).save(f"{OUT}/textures/gui/mark.png")
for name, fn in ICONS.items():
    fn().resize((64, 64), Image.LANCZOS).save(f"{OUT}/textures/gui/icons/category_{name}.png")
print("generated", 3 + len(ICONS), "textures")
